REQ_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/339713028482/1229378256-req-queue'
RESP_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/339713028482/1229378256-resp-queue'
S3_IN_BUCKET = '1229378256-in-bucket'
S3_OUT_BUCKET = '1229378256-out-bucket'
